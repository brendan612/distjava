package com.brendanjbishop.project6.models.cart;

/**
 *
 * @author Brendan Bishop | brendan@brendanjbishop.com
 * @since 1.8
 */
public final class CartService {
    private Cart cart;
    
    public CartService(){
        cart = new Cart();
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
    
    

}
