/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brendanjbishop.project6.beans;

import com.brendanjbishop.project6.models.cart.Cart;
import com.brendanjbishop.project6.models.cart.CartService;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;


/**
 *
 * @author Bren
 */
@Named(value = "cartBean")
@SessionScoped
public class CartBean implements Serializable {

    private final String sessionId;
    private final Cart cart;
    private final CartService cartService = new CartService();
    
    /**
     * Creates a new instance of CartBean
     */   
    public CartBean(){
        FacesContext facesContext = FacesContext.getCurrentInstance();
        sessionId = facesContext.getExternalContext().getSessionId(true);
        cart = cartService.getCart();
    }
    
    public int getItemsInCart(){
        return cart.getItemsInCart();
    }
    
    
    
    
    
}
