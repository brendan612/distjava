package com.brendanjbishop.project6.models.cart;

import com.brendanjbishop.project6.models.product.Product;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Brendan Bishop | brendan@brendanjbishop.com
 * @since 1.8
 */
public final class Cart {

    private Map<Product,Integer> products;
    
    public Cart(){
        products = new HashMap<>();
    }
    
    public void addProduct(Product product, int quantity){
        if(product != null)
            products.put(product, quantity);
    }
    
    public void setProducts(Map<Product,Integer> products){
        this.products = products;
    }
    
    public Map<Product,Integer> getProducts(){
        return this.products;
    }
    
    public int getItemsInCart(){
        int i = 0;
        i = products.entrySet().stream().map((product) -> product.getValue()).reduce(i, Integer::sum);
        return i;
    }
}
