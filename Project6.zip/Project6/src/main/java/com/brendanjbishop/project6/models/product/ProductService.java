package com.brendanjbishop.project6.models.product;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Brendan Bishop | brendan@brendanjbishop.com
 * @since 1.8
 */
public final class ProductService {

    private final List<Product> products = Arrays.asList(
            new Product("A1", "Toilet", "big ol toilet", 144.26),
            new Product("A2", "Pineapple", "them good spikey boi", 9.49),
            new Product("A3", "Pole Barn", "big house", 12.23)
    );

    public List<Product> getAllProducts() {
        return products;
    }

    public Product getProductById(String id) {
        if (id != null && id.length() > 0) {
            for (Product p : products) {
                if (p.getId().equalsIgnoreCase(id)) {
                    return p;
                }
            }
        }
        return null;
    }

    public List<Product> findProducts(String search) {
        List<Product> ret = new ArrayList<>();
        for (Product p : products) {
            search = search.toLowerCase();
            if (p.nameContainsIgnoreCase(search)) {
                ret.add(p);
            }
        }
        return ret;
    }
}
