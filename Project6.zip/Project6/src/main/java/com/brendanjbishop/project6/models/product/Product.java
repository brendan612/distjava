package com.brendanjbishop.project6.models.product;

/**
 *
 * @author Brendan Bishop | brendan@brendanjbishop.com
 * @since 1.8
 */
public final class Product {

    private String id, name, desc;
    private double price;

    public Product(String id, String name, String desc, double price) {
        setId(id);
        setName(name);
        setDesc(desc);
        setPrice(price);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean nameContainsIgnoreCase(String search) {
        return this.name.toLowerCase().contains(search)
                || this.name.toUpperCase().contains(search);
    }
}
