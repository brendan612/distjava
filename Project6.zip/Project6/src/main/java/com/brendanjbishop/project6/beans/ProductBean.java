/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brendanjbishop.project6.beans;

import com.brendanjbishop.project6.models.product.Product;
import com.brendanjbishop.project6.models.product.ProductService;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

/**
 *
 * @author Bren
 */
@javax.faces.bean.SessionScoped
@ManagedBean(name="productBean")
@Dependent
public class ProductBean implements Serializable {

    private final ProductService productService = new ProductService();
    
    @ManagedProperty(name="query", value="")
    private String query;
    @ManagedProperty(name="id", value="")
    private String id;
    @ManagedProperty(name="products",value="")
    private List<Product> products;
    @ManagedProperty(name="product",value="")
    private Product product;
    /**
     * Creates a new instance of ProductBean
     */
    public ProductBean() {
        setProducts(productService.getAllProducts());
    }

    public String allProducts(){
        return "productList";
    }
    
    public String getProductById(){
        setProduct(productService.getProductById(id));
        if(product == null)
            return "productList";
        return "productInfo";
    }
    
    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
    
}
