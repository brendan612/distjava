package com.brendanjbishop.p3.model;

import java.util.ArrayList;
import java.util.List;

public class ProductService {

    public Product getProductById(String id){
        Product p = new Product("Water",id,1.92);
        return p;
    }
    
    public List<Product> getProductsBySearch(){
        List<Product> l = new ArrayList<>();
        l.add(new Product("Butter","A2",34.34));
        l.add(new Product("Apples","A3",4.74));
        l.add(new Product("Chocolate","A4",9.21));
        return l;
    }
}
