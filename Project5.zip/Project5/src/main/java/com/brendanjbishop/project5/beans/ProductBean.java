package com.brendanjbishop.project5.beans;

import com.brendanjbishop.project5.model.Product;
import com.brendanjbishop.project5.model.ProductService;
import javax.enterprise.context.Dependent;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

@SessionScoped
@ManagedBean(name="productBean")
@Dependent
public final class ProductBean implements Serializable{
	@ManagedProperty(name="searchString", value="")
	private	String searchString;
	@ManagedProperty(name="searchId", value="")
	private String searchId;
	private final ProductService productService = new ProductService();
	@ManagedProperty(name="products", value="")
	private List<Product> products;
	@ManagedProperty(name="product", value="")
	private Product product;
	
	public ProductBean() {
		setProducts(productService.getAllProducts());
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> prod) {
		if(prod != null)
			products = prod;
		System.out.println("products = " + products);
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product prod) {
		if(prod != null)
			product = prod;
		System.out.println("product = " + product);
	}

	public String getSearchString() {
		return searchString;
	}
	
	public void setSearchId(String search) {
		if(search != null && !search.isEmpty())
			searchId = search;
		System.out.println(search + " = searchId");
	}

	public void setSearchString(String search) {
		if(search != null)
			searchString = search;
		System.out.println("searchString = " + searchString);
	}

	public String getSearchId() {
		return searchId;
	}

	public String searchProductsById(){
		setProduct(productService.getProductById(searchId));
		if(product == null)
			return "productList";
		return "productInfo";
	}
	
	public String allProducts(){
		return "productList";
	}
	
	public void productDetail(AjaxBehaviorEvent event){
		try{
			FacesContext.getCurrentInstance().getExternalContext().redirect("/Project5/productInfo.xhtml");
		}catch(IOException e){
			FacesMessage message = new FacesMessage("IOException", product.getId());
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
	}
}
