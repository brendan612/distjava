package com.brendanjbishop.project5.model;

import java.util.List;

public class CartService {
	private Cart cart;
	
	public CartService(Cart cart){
            setCart(cart);
	}

    public void setCart(Cart cart) {
        this.cart = cart;
    }
	
        
	public Cart getCart(){
		return cart;
	}
}
