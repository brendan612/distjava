package com.brendanjbishop.project5.beans;

import com.brendanjbishop.project5.model.Cart;
import com.brendanjbishop.project5.model.CartService;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author David
 */
@Named(value = "shoppingCartBean")
@Dependent
@SessionScoped
public class CartBean {
	private final CartService cartService;
	private Cart cart;
	private double total;

	public CartBean() {
		cartService = new CartService(cart);
		setCart(cartService.getCart());
	}

	public Cart getCart() {
		return cart;
	}
	
	public double getTotal(){
		return total;
	}
	
	public void setCart(Cart cart){
		if(cart != null)
                    this.cart = cart;
	}
}
