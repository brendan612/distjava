package com.brendanjbishop.project5.model;

import java.util.List;

public final class Cart {
	private List<Product> products;
        public Cart(List<Product> products) {
            this.products = products;
        }
        
        public void addProduct(Product p){
            if(p != null)
                products.add(p);
        }
        
        public void setProducts(List<Product> p){
            this.products = p;
        }
        
        public List<Product> getProducts(){
            return this.products;
        }
}
